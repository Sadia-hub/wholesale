import java.lang.*;
import activity.*;

public class Start {
	public static void main(String args[]) {
		LoginActivity la = new LoginActivity();
		la.setVisible(true);
	}
}